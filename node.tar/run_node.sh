docker pull aergo/node
docker stop aergo-node
docker run -d --rm --name aergo-node \
	-p 7845:7845 \
	-p 7846:7846 \
	-v /home/seo/aergo-node:/aergo \
	aergo/node \
	aergosvr --home /aergo --config /aergo/config.toml
